# Question 1
100 Points

The requirements for the final project are listed below. This is worth 100 points and must be submitted by 11:55pm Eastern time DEC. 4th. all files (images, css, etc.) must be submitted for full credit. You can use the image map maker at https://www.image-map.net/ to help you with the coordinates for your image map. Very important - I expect a thought-out site with your own code! Do not just copy and paste code from the homework and expect a passing score.


* 1. 5 html pages (with navigation to each on each page)
* 2. 1 table (with table header) with at least five rows and one colspan
* 3. minimum of 3 external hyperlinks (one of which must be an email link)
* 4. external stylesheet with style for at least five different elements (body, p, etc. )
* 5. at least 2 images with alt tags
* 6. contact form with at least 5 elements (text box, radio buttons, etc.)
* 7. an image map with at least three area elements
* 8. at least one page must have two columns
* 9. paragraph and heading tags used as appropriate
* 10. an ordered list with at list 5 items


The toolbar will appear after you click in the submission box.

Samples:
* https://www.goldsgym.com/
